/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <stdbool.h>
#include "project.h"

#define NUM_WAIT_POINTS         1000
#define NUM_CAL_POINTS          100

void adc_calibration(void);

extern bool adc_calibration_flag;
extern uint16 status_enable_counter;
extern uint32_t IFA_calibrate_offset_buf[NUM_CAL_POINTS];
extern uint32_t IFB_calibrate_offset_buf[NUM_CAL_POINTS];
extern uint32_t IFA_calibrate_offset_val;
extern uint32_t IFB_calibrate_offset_val;
extern uint32_t calibration_counter;

/* [] END OF FILE */
