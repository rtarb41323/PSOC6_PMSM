/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "math.h"
#include "adc_calibration.h"

//////////////////////
// #defines here
#define FLOAT_2PI   6.28318530718f
#define DEBUG_SAMPLES      10
#define SQRT3               1.73205080757
#define _SQRT3_2            0.86602540378
#define one_over_SQRT3      0.57735026919
#define _constrain(amt,low,high) ((amt)<(low)?(low):((amt)>(high)?(high):(amt)))
#define PWM_MAX_PCT     0.96
#define PWM_MIN_PCT     0.04

//////////////////////////////
/*working variables*/
uint16 idle_counter = 0;
uint32_t ADC_In_Values[3] = {0, 0, 0}; //This array holds our ADC values from the DMA transfer
uint32_t pwmPeriod = 0; //Used to hold the period setting of the PWM modules in the schematic
uint32_t duty_cycle_offset = 0;
uint32_t rmt_dummy_pwm_A_val = 0;
uint32_t rmt_dummy_pwm_B_val = 0;
uint32_t rmt_dummy_pwm_C_val = 0;


float MANG = 0.0f;
float VFF = 0.0f;
float TICK_PERIOD = 1 / 20000;
float MPOL_HALF;
float COFF_RAD;
float EANG = 0.0f;
float EANG_SIN = 0.0f;
float EANG_COS = 0.0f;

float i_alpha, i_beta;
float I_d, I_q, I_dref, I_qref;
float I_d_err, I_q_err;
float V_d, V_q;

int32_t IFA_current_counts = 0;
int32_t IFB_current_counts = 0;
uint32_t Vbus_counts = 0;

float IFA_current_f = 0;
float IFB_current_f = 0;
float IFC_current_f = 0;
float Vbus_volts_f = 0;

float current_array_debug_A_f[DEBUG_SAMPLES]; //rmt debug
float current_array_debug_B_f[DEBUG_SAMPLES]; //rmt debug

float curloop_prop_gain = 0.8f;
float curloop_int_gain = 100.0f;
float curloop_int_hold_d = 0.0f;
float curloop_int_hold_q = 0.0f;
float curloop_int_OUT_d = 0.0f;
float curloop_int_OUT_q = 0.0f;
float curloop_prop_d_OUT = 0.0f;
float curloop_prop_q_OUT = 0.0f;

float int_dt = 1.0f / 20000.0f; //Sampling period
float duty_out_f = 0.0f;


float i_alpha = 0.0f;
float i_beta = 0.0f;
float V_alpha = 0.0f;
float V_beta = 0.0f;
float dq_d_cur_meas = 0.0f;
float dq_q_cur_meas = 0.0f;
float theta_f = 0.0f;  //Angle
float dq_d_cur_REF = 0.0f;
float dq_q_cur_REF = 0.0f;
float dq_d_cur_err = 0.0f;
float dq_q_cur_err = 0.0f;
float Vd = 0.0f;
float Vq = 0.0f;
float Va, Vb, Vc;  
float duty_A_pct, duty_B_pct, duty_C_pct;
uint32_t duty_A_counts, duty_B_counts, duty_C_counts;
uint32_t duty_out_counts_A = 0;
uint32_t duty_out_counts_B = 0;
uint32_t duty_out_counts_C = 0;

////////////////////////
//Debug variables here
float duty_A_pct_rmt = 0.50;
float duty_B_pct_rmt = 0.50;
float duty_C_pct_rmt = 0.50;


/**********************************
Function Prototypes:
**********************************/
void ISR_Control_Loop_handler(void);  //Our control loop ISR 
float wrap_angle(float theta);        //Function to wrap theta angle to between 0 and 2*pi


int main(void)
{
    __enable_irq(); /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    
    //////////////////////////////////////////////////////////////
    // CONFIGURE THE INTERRUPTS:
    Cy_SysInt_Init(&ADC_done_intrpt_cfg, ISR_Control_Loop_handler); //Tying schematic interrupt to ISR handler function
    NVIC_ClearPendingIRQ(ADC_done_intrpt_cfg.intrSrc); //Clear any pending interrupts from this source
    NVIC_EnableIRQ(ADC_done_intrpt_cfg.intrSrc);
    //////////////////////////////////////////////////////////////
    
    Fault_Control_Reg_Write(0); //To start, we are NOT faulted, so set fault control reg to logic "0"
    
    //Delay here to give the motor driver board time to power up:
    for (uint16 delay_counter = 0; delay_counter < 1000; delay_counter++)
    {
        CyDelayUs(1000); //1 millisec
    }
    

    
    //Enable PWM Phase A:
    (void) Cy_TCPWM_PWM_Init(PWM_PHASE_A_HW, PWM_PHASE_A_CNT_NUM, &PWM_PHASE_A_config);
    Cy_TCPWM_Enable_Multiple(PWM_PHASE_A_HW, PWM_PHASE_A_CNT_MASK);
    //Enable PWM Phase B:
    (void) Cy_TCPWM_PWM_Init(PWM_PHASE_B_HW, PWM_PHASE_B_CNT_NUM, &PWM_PHASE_B_config);
    Cy_TCPWM_Enable_Multiple(PWM_PHASE_B_HW, PWM_PHASE_B_CNT_MASK);
    //Enable PWM Phase C:
    (void) Cy_TCPWM_PWM_Init(PWM_PHASE_C_HW, PWM_PHASE_C_CNT_NUM, &PWM_PHASE_C_config);
    Cy_TCPWM_Enable_Multiple(PWM_PHASE_C_HW, PWM_PHASE_C_CNT_MASK);
    
    //...read the PWM period from the schematic
    pwmPeriod = PWM_PHASE_A_GetPeriod0();
    duty_cycle_offset = pwmPeriod / 2; 
  
    //Enable PWM ADC Trigger:
    (void) Cy_TCPWM_PWM_Init(PWM_ADC_TRIG_HW, PWM_ADC_TRIG_CNT_NUM, &PWM_ADC_TRIG_config);
    Cy_TCPWM_Enable_Multiple(PWM_ADC_TRIG_HW, PWM_ADC_TRIG_CNT_MASK);    
    PWM_ADC_TRIG_SetCompare0( pwmPeriod - 2 ); 
    
    
    
    //Enable the SAR ADC:
    ADC_1_Start();
    //Setup and start the DMA transfer:
    DMA_1_Start( (uint32_t*)&(SAR->CHAN_RESULT[0]),  //Source
               ADC_In_Values);                       //Destination
    //Enable the PWMs:
    PWM_SYNC_control_reg_Write(1);
    
    //Set the PWM periods to "0" when we are injecting test currents into the 
    //current shunt for ADC calibration purposes:
    //PWM_PHASE_A_SetCompare0( (uint16_t)(0) ); //rmt debug dummy value
    //PWM_PHASE_B_SetCompare0( (uint16_t)(0) ); //rmt debug dummy value
    //PWM_PHASE_C_SetCompare0( (uint16_t)(0) ); //rmt debug dummy value
    
       
    for(;;)
    {
        idle_counter = (idle_counter + 1) % 32768;
        
        /* Place your application code here. */
        //PWM_PHASE_A_SetCompare0( (uint16_t)(rmt_dummy_pwm_A_val) ); //rmt debug dummy value
        //PWM_PHASE_B_SetCompare0( (uint16_t)(rmt_dummy_pwm_B_val) ); //rmt debug dummy value
        //PWM_PHASE_C_SetCompare0( (uint16_t)(rmt_dummy_pwm_C_val) ); //rmt debug dummy value
        
        //Test reference currents injected here:
        dq_d_cur_REF = 0.0f;
        dq_q_cur_REF = 0.5f;
        
    }
}




volatile uint16 intrpt_counter = 0; 
volatile uint16 clarke_xform_counter = 0; 

void ISR_Control_Loop_handler(void)
{
    intrpt_counter++;   
      
    //////////////////////////////////////////////////////////////////////
    // Enabled or not?
    if(Enabled_Status_Reg_Read() == 0) //we are NOT enabled
    {
        status_enable_counter = 0; //reset the counter
        adc_calibration_flag = false;
        
        //Reset the PI integrators:
        curloop_int_hold_d = 0;
        curloop_int_hold_q = 0;
        //Set the PWM outputs to 50% for all channels:
        PWM_PHASE_A_SetCompare0( duty_cycle_offset );
        PWM_PHASE_B_SetCompare0( duty_cycle_offset );
        PWM_PHASE_C_SetCompare0( duty_cycle_offset ); 
    }
    else //we ARE enabled
    {
        if (adc_calibration_flag == false) //if we are NOT calibrated, then start calibration:
        {
            adc_calibration();
            status_enable_counter++;
            
            //Reset the PI integrators:
            curloop_int_hold_d = 0;
            curloop_int_hold_q = 0;
            //Set the PWM outputs to "0" for all channels:
            PWM_PHASE_A_SetCompare0( 0 );
            PWM_PHASE_B_SetCompare0( 0 );
            PWM_PHASE_C_SetCompare0( 0 ); 
        }
        else {} //If we ARE calibrated, then do nothing and continue 
    }   
    //////////////////////////////////////////////////////////////////////
    
    //Get phase currents and bus voltage here:
    IFA_current_counts = ((int32_t)(ADC_In_Values[0] & 0xFFF)) - ((int32_t)IFA_calibrate_offset_val);
    IFB_current_counts = ((int32_t)(ADC_In_Values[1] & 0xFFF)) - ((int32_t)IFB_calibrate_offset_val);
    Vbus_counts = (ADC_In_Values[2] & 0xFFF);
    
    IFA_current_f = -1.0f * (((float)IFA_current_counts)*0.01905 - 0.00925);
    IFB_current_f = -1.0f * (((float)IFB_current_counts)*0.01905 - 0.00925);
    IFC_current_f = -1.0f * (IFA_current_f + IFB_current_f);
    Vbus_volts_f = ((float)Vbus_counts)*0.2023 + 0.3852;
    
    current_array_debug_A_f[(intrpt_counter % DEBUG_SAMPLES)] = IFA_current_f;
    current_array_debug_B_f[(intrpt_counter % DEBUG_SAMPLES)] = IFB_current_f;

    
    ////////////////////////////////////////////////////////////////////////
    // If we are NOT enabled, or we are NOT calibrated, then return here so
    // that we don't run the current loop update:
    ////////////////////////////////////////////////////////////////////////
    if ((Enabled_Status_Reg_Read() == 0) || (adc_calibration_flag == false))
    {
        return;
    }    
    
    //////////////////////
    //RMT debug for theta angle:
    theta_f = theta_f - 0.002;
    
    ///////////////////////
    //Clarke transform:
    clarke_xform_counter++;
    i_alpha = IFA_current_f;
    i_beta = (IFA_current_f + 2*IFB_current_f) * one_over_SQRT3;
    ///////////////////////
    //Park transform:
    theta_f = wrap_angle(theta_f);  //wrap angle to between 0 and 2pi
    dq_d_cur_meas = i_alpha*cosf(theta_f) + i_beta*sinf(theta_f);
    dq_q_cur_meas = -i_alpha*sinf(theta_f) + i_beta*cosf(theta_f);
    
    ///////////////////////
    //PI loop regulation:
    /* error */
    dq_d_cur_err =  dq_d_cur_REF - dq_d_cur_meas;
    dq_q_cur_err =  dq_q_cur_REF - dq_q_cur_meas;
    
    /* proportional */
    curloop_prop_d_OUT =  curloop_prop_gain * dq_d_cur_err; 
    curloop_prop_q_OUT =  curloop_prop_gain * dq_q_cur_err;
    /* integral */
    curloop_int_hold_d +=  dq_d_cur_err * int_dt;   //integral
    curloop_int_hold_q +=  dq_q_cur_err * int_dt;   //integral    
    curloop_int_OUT_d = curloop_int_gain * curloop_int_hold_d;
    curloop_int_OUT_q = curloop_int_gain * curloop_int_hold_q;

    //Vd and Vq:
    Vd = curloop_int_OUT_d + curloop_prop_d_OUT;
    Vq = curloop_int_OUT_q + curloop_prop_q_OUT;
    
    //rmt debug here
    //Vd = 0;
    //Vq = 0;
    //theta = 0;
    
    ///////////////////////////////////
    /* INVERSE D-Q XFORM STARTS HERE */
    ///////////////////////////////////
        
    //dq --> Alpha and Beta (inverse park)
    V_alpha = Vd * cosf(theta_f)  -   Vq * sinf(theta_f);
    V_beta  = Vd * sinf(theta_f)  +   Vq * cosf(theta_f);    
       
    //Park --> Clark
    Va = V_alpha;
    Vb = -0.5f * V_alpha + _SQRT3_2 * V_beta;
    Vc = -0.5f * V_alpha - _SQRT3_2 * V_beta;
    
    duty_A_pct = _constrain((Va / Vbus_volts_f) + 0.50, PWM_MIN_PCT, PWM_MAX_PCT); //duty_A is a percentage
    duty_B_pct = _constrain((Vb / Vbus_volts_f) + 0.50, PWM_MIN_PCT, PWM_MAX_PCT); //duty_B is a percentage
    duty_C_pct = _constrain((Vc / Vbus_volts_f) + 0.50, PWM_MIN_PCT, PWM_MAX_PCT); //duty_C is a percentage
    //duty_A_pct = duty_A_pct_rmt;
    //duty_B_pct = duty_B_pct_rmt;
    //duty_C_pct = duty_C_pct_rmt;
    
    duty_A_counts = (uint32_t)(duty_A_pct * ((float)pwmPeriod));
    duty_B_counts = (uint32_t)(duty_B_pct * ((float)pwmPeriod));
    duty_C_counts = (uint32_t)(duty_C_pct * ((float)pwmPeriod));
    
    /* Set duty cycles here */ 
    /////////////////////////
    duty_out_counts_A = duty_A_counts;
    PWM_PHASE_A_SetCompare0(duty_out_counts_A);
    /////////////////////////
    duty_out_counts_B = duty_B_counts;
    PWM_PHASE_B_SetCompare0(duty_out_counts_B);
    /////////////////////////
    duty_out_counts_C = duty_C_counts;
    PWM_PHASE_C_SetCompare0(duty_out_counts_C);

    
    return;
   
}


float wrap_angle(float theta_f) {
    float two_pi = 2.0 * M_PI;
    
    // Use fmod to get the remainder of theta divided by 2π
    theta_f = fmod(theta_f, two_pi);
    
    // If theta is negative, wrap it to the positive range
    while (theta_f < 0) {
        theta_f += two_pi;
    }
    
    return theta_f;
}



/* [] END OF FILE */
