/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <stdbool.h>
#include "project.h"
#include "adc_calibration.h"


bool adc_calibration_flag = false;
uint16 status_enable_counter = 0;

uint32_t IFA_calibrate_offset_buf[NUM_CAL_POINTS];
uint32_t IFB_calibrate_offset_buf[NUM_CAL_POINTS];
uint32_t IFA_calibrate_offset_val = 0;
uint32_t IFB_calibrate_offset_val = 0;
uint32_t calibration_counter = 0;

//Variables declared in other files:
extern uint32_t ADC_In_Values[3];

void adc_calibration(void)
{
    //////////////////////////////////////////////////////////////////////
    //Calibration?
    //////////////////////////////////////////////////////////////////////
    //if the status enable counter is between 0 and NUM_WAIT_POINTS, then wait for the analog
    //outputs on the motor driver board to "settle":
    if (status_enable_counter < NUM_WAIT_POINTS)
    {        
        return;   
    }
    else if (status_enable_counter == NUM_WAIT_POINTS)
    {//Get ready to calibrate by zeroing out all old buffers and old values:
        for (int dummy_i = 0; dummy_i < NUM_CAL_POINTS; dummy_i++)
        {
            IFA_calibrate_offset_buf[dummy_i] = 0;
            IFB_calibrate_offset_buf[dummy_i] = 0;
        }
        IFA_calibrate_offset_val = 0;
        IFB_calibrate_offset_val = 0;
        calibration_counter = 0;
        return;
    }       
    else if ( (status_enable_counter > NUM_WAIT_POINTS) && (status_enable_counter <= (NUM_WAIT_POINTS + NUM_CAL_POINTS) ) )
    {//Begin taking ADC samples for calibration:           
        IFA_calibrate_offset_buf[calibration_counter] += (ADC_In_Values[0] & 0xFFF);
        IFB_calibrate_offset_buf[calibration_counter] += (ADC_In_Values[1] & 0xFFF);
        calibration_counter++;
        return;
    }
    else if ( status_enable_counter == (NUM_WAIT_POINTS + NUM_CAL_POINTS + 1) )
    {
        //We are done calibrating, so now, average out the samples:
        for (int dummy_i = 0; dummy_i < NUM_CAL_POINTS; dummy_i++)
        {
            IFA_calibrate_offset_val += IFA_calibrate_offset_buf[dummy_i];
            IFB_calibrate_offset_val += IFB_calibrate_offset_buf[dummy_i];
        }                    
        IFA_calibrate_offset_val = IFA_calibrate_offset_val / NUM_CAL_POINTS;
        IFB_calibrate_offset_val = IFB_calibrate_offset_val / NUM_CAL_POINTS;
        return;
    }
    //if the status enable counter is above , then run the motor control algorithm
    else if ( status_enable_counter > (NUM_WAIT_POINTS + NUM_CAL_POINTS + 1) )    
    {
        adc_calibration_flag = true;
        return;
    } 
    
}

/* [] END OF FILE */
